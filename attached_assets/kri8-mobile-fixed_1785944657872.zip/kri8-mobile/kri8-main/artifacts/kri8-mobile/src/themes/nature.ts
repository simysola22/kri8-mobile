import type { Theme } from './types';

// Ported 1:1 from the web app's .theme-nature tokens.
export const nature: Theme = {
  name: 'nature',
  label: 'Nature',

  bg: '#081C12',
  bgSurface: '#112C1F',
  bgGlass: 'rgba(74, 222, 128, 0.05)',
  bgGlassDeep: 'rgba(74, 222, 128, 0.07)',

  border: 'rgba(74, 222, 128, 0.10)',
  borderActive: 'rgba(53, 212, 111, 0.55)',

  blur: 24,

  accent: '#35D46F',
  accentSoft: 'rgba(74, 222, 128, 0.14)',
  accentContrast: '#081C12',

  text: '#F2F2F2',
  textMuted: '#7EA994',
  textFaint: 'rgba(242, 242, 242, 0.28)',

  success: '#4ADE80',
  warning: '#FBBF24',
  error: '#F87171',

  gradient: ['#0D261A', '#081C12'],
  accentGradient: ['#78E29F', '#35D46F'],

  tabBarBg: 'rgba(8, 28, 18, 0.92)',
  tabBarActive: '#35D46F',
  tabBarInactive: 'rgba(126, 169, 148, 0.65)',

  statusBar: 'light-content',
};
