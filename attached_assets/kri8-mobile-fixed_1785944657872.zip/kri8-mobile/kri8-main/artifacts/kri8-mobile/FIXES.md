# Kri8 Mobile (Expo Router build)

## What was fixed in this pass

1. **Theme colors** — all 8 theme files in `src/themes/` were rewritten to
   match the real web app's `index.css` tokens exactly (converted from the
   same HSL values). Previously these used an invented palette (e.g. a
   purple `#7C6EF5` accent instead of the web's actual gold
   `hsl(43, 74%, 52%)` for Midnight).

2. **SDK version bump** — `expo` was pinned to SDK 53 / React Native 0.79.3.
   Expo Go on current devices runs SDK 54 and will refuse to open an SDK 53
   project. Bumped to Expo `^54.0.0`, React Native `0.81.5`, and all
   `expo-*`/`react-native-*` packages to their SDK 54–compatible versions.
   `react-native-reanimated` was bumped to `~4.1.1`, which requires the new
   `react-native-worklets` peer dependency — added that too.

3. **`babel-preset-expo` was missing** from `package.json` despite being
   referenced in `babel.config.js` — added it to `devDependencies`.

4. **Documented (not code-changed) the two dead-code services**:
   `StorageService.ts` and `CreatorScoreService.ts` call backend routes
   (`/api/storage/*`, `/api/users/{id}/creator-score`) that don't exist on
   the real Express API yet. Neither is currently imported by any screen,
   so they can't crash anything today — but both now have a clear header
   comment saying so, so whoever wires them in next knows the backend work
   needs to happen first. `NotificationService`'s push-token registration
   *is* wired into `app/_layout.tsx`, but was already wrapped in a
   try/catch that fails silently — no change needed there.

## Why you can't just run this in Expo Go

This app depends on `react-native-mmkv` (native module for the offline
queue) plus config plugins for camera, notifications, and universal links
(`associatedDomains`). None of that is included in the stock Expo Go app —
it needs a **custom development build** instead.

### One-time setup for a dev client

```bash
npm install
npx expo prebuild --clean       # generates native ios/ and android/ folders
npx eas build --profile development --platform android   # or ios
```

That produces an installable `.apk`/`.ipa` with a QR code — install it on
your phone once (same as installing any app), and from then on:

```bash
npx expo start --dev-client
```

...scans and reloads exactly like Expo Go did, but with all the native
modules this app actually needs.

If you don't have an Expo/EAS account yet, `npx eas build` will walk you
through creating one — it's free for development builds, just rate-limited
on the free tier.
